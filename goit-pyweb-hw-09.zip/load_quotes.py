
import json
import re
from pathlib import Path

import connect
from models import Author, Quote


BASE_DIR = Path(__file__).parent
QUOTES_FILE = BASE_DIR / "quotes.json"


def normalize_name(name):
    return re.sub(r"[^a-z0-9]", "", name.casefold())


def load_quotes():
    with QUOTES_FILE.open("r", encoding="utf-8") as file:
        quotes_data = json.load(file)

    authors = list(Author.objects)
    authors_by_name = {
        normalize_name(author.fullname): author
        for author in authors
    }

    imported = 0
    skipped = 0

    for data in quotes_data:
        author_name = data["author"]
        author = authors_by_name.get(normalize_name(author_name))

        if author is None:
            print(f"Не знайдено автора: {author_name}")
            skipped += 1
            continue

        Quote.objects(
            quote=data["quote"],
            author=author,
        ).modify(
            upsert=True,
            new=True,
            set__quote=data["quote"],
            set__author=author,
            set__tags=data.get("tags", []),
        )

        imported += 1

    print(f"Цитат у JSON: {len(quotes_data)}")
    print(f"Оброблено цитат: {imported}")
    print(f"Пропущено цитат: {skipped}")
    print(f"Цитат у базі: {Quote.objects.count()}")


if __name__ == "__main__":
    load_quotes()
