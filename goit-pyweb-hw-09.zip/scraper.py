
import json
import time
from pathlib import Path
from urllib.parse import urljoin

import requests
from bs4 import BeautifulSoup


BASE_URL = "https://quotes.toscrape.com/"
OUTPUT_DIR = Path(__file__).parent

HEADERS = {
    "User-Agent": "Mozilla/5.0"
}

session = requests.Session()
session.headers.update(HEADERS)


def get_soup(url):
    response = session.get(url, timeout=30)
    response.raise_for_status()
    return BeautifulSoup(response.text, "html.parser")


def scrape_quotes():
    quotes = []
    authors = {}
    next_url = BASE_URL

    while next_url:
        print(f"Збираємо цитати: {next_url}", flush=True)
        soup = get_soup(next_url)

        for quote_block in soup.select(".quote"):
            quote_text = quote_block.select_one(".text").get_text(
                strip=True
            )
            author_name = quote_block.select_one(".author").get_text(
                strip=True
            )
            tags = [
                tag.get_text(strip=True)
                for tag in quote_block.select(".tags .tag")
            ]

            author_link = quote_block.select_one(
                "a[href*='/author/']"
            )

            if author_link:
                author_url = urljoin(BASE_URL, author_link["href"])
                authors[author_url] = author_name

            quotes.append({
                "tags": tags,
                "author": author_name,
                "quote": quote_text
            })

        next_link = soup.select_one("li.next a")

        if next_link:
            next_url = urljoin(BASE_URL, next_link["href"])
        else:
            next_url = None

        time.sleep(0.2)

    return quotes, authors


def scrape_author(author_url, author_name):
    print(f"Збираємо автора: {author_name}", flush=True)
    soup = get_soup(author_url)

    fullname = soup.select_one(".author-title")
    born_date = soup.select_one(".author-born-date")
    born_location = soup.select_one(".author-born-location")
    description = soup.select_one(".author-description")

    return {
        "fullname": (
            fullname.get_text(strip=True) if fullname else author_name
        ),
        "born_date": (
            born_date.get_text(strip=True) if born_date else ""
        ),
        "born_location": (
            born_location.get_text(strip=True) if born_location else ""
        ),
        "description": (
            description.get_text(" ", strip=True) if description else ""
        )
    }


def save_json(filename, data):
    file_path = OUTPUT_DIR / filename

    with file_path.open("w", encoding="utf-8") as file:
        json.dump(data, file, ensure_ascii=False, indent=2)

    print(f"Файл {filename} збережено. Записів: {len(data)}")


def main():
    try:
        quotes, author_links = scrape_quotes()

        print(f"\nУсього цитат: {len(quotes)}")
        print(f"Унікальних авторів: {len(author_links)}")

        authors = []

        for author_url, author_name in author_links.items():
            try:
                authors.append(scrape_author(author_url, author_name))
                time.sleep(0.2)
            except requests.RequestException as error:
                print(f"Помилка автора {author_name}: {error}")

        save_json("quotes.json", quotes)
        save_json("authors.json", authors)

        print("\nСкрапінг завершено!")

    except requests.RequestException as error:
        print(f"Помилка HTTP-запиту: {error}")


if __name__ == "__main__":
    main()
