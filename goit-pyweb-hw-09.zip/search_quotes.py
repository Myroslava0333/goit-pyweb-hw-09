
import re

import connect
from mongoengine.queryset.visitor import Q
from models import Author, Quote


def print_quotes(quotes):
    quotes = list(quotes)

    if not quotes:
        print("Нічого не знайдено.")
        return

    for quote in quotes:
        print("\n" + "=" * 60)
        print(f"Автор: {quote.author.fullname}")
        print(f"Цитата: {quote.quote}")
        print(f"Теги: {', '.join(quote.tags)}")

    print(f"\nЗнайдено цитат: {len(quotes)}")


def search_by_name(name):
    authors = list(Author.objects(fullname__icontains=name))

    if not authors:
        print("Авторів із таким ім'ям не знайдено.")
        return

    print_quotes(Quote.objects(author__in=authors))


def search_by_tag(tag):
    pattern = re.compile(re.escape(tag.strip()), re.IGNORECASE)
    print_quotes(Quote.objects(tags__in=[pattern]))


def search_by_tags(tags):
    tag_list = [tag.strip() for tag in tags.split(",") if tag.strip()]

    if not tag_list:
        print("Вкажи хоча б один тег.")
        return

    query = None

    for tag in tag_list:
        pattern = re.compile(re.escape(tag), re.IGNORECASE)
        condition = Q(tags__in=[pattern])
        query = condition if query is None else query | condition

    print_quotes(Quote.objects(query))


def main():
    print("Пошук цитат")
    print("name: ім'я автора")
    print("tag: один тег")
    print("tags: тег1, тег2")
    print("exit — вихід")

    while True:
        try:
            command = input("\nВведи команду: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nРоботу завершено.")
            break

        if command.lower() == "exit":
            print("Роботу завершено.")
            break

        if ":" not in command:
            print("Невірний формат команди.")
            continue

        command_name, value = command.split(":", 1)
        command_name = command_name.strip().lower()
        value = value.strip()

        if not value:
            print("Після команди потрібно вказати значення.")
        elif command_name == "name":
            search_by_name(value)
        elif command_name == "tag":
            search_by_tag(value)
        elif command_name == "tags":
            search_by_tags(value)
        else:
            print("Невідома команда.")


if __name__ == "__main__":
    main()
