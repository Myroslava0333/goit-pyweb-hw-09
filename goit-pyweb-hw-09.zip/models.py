
from mongoengine import (
    Document,
    StringField,
    ListField,
    ReferenceField,
)


class Author(Document):
    fullname = StringField(required=True)
    born_date = StringField()
    born_location = StringField()
    description = StringField()

    meta = {
        "collection": "authors"
    }


class Quote(Document):
    tags = ListField(StringField(), default=list)
    author = ReferenceField(Author, required=True)
    quote = StringField(required=True)

    meta = {
        "collection": "quotes"
    }
