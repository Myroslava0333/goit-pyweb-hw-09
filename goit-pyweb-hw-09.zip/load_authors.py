
import json
from pathlib import Path

import connect
from models import Author


BASE_DIR = Path(__file__).parent
AUTHORS_FILE = BASE_DIR / "authors.json"


def load_authors():
    with AUTHORS_FILE.open("r", encoding="utf-8") as file:
        authors_data = json.load(file)

    for data in authors_data:
        Author.objects(fullname=data["fullname"]).modify(
            upsert=True,
            new=True,
            set__fullname=data["fullname"],
            set__born_date=data.get("born_date", ""),
            set__born_location=data.get("born_location", ""),
            set__description=data.get("description", ""),
        )

    print(f"Оброблено авторів: {len(authors_data)}")
    print(f"Авторів у базі: {Author.objects.count()}")


if __name__ == "__main__":
    load_authors()
